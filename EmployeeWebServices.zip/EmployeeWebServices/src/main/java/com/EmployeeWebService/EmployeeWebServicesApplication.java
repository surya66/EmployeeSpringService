package com.EmployeeWebService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeWebServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeWebServicesApplication.class, args);
	}

}
